﻿using System;
using System.Collections.Generic;

namespace BlueBird.Models;

public partial class Payment
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string RoomType { get; set; } = null!;

    public string Bed { get; set; } = null!;

    public int NoofRoom { get; set; }

    public DateOnly Cin { get; set; }

    public DateOnly Cout { get; set; }

    public int Noofdays { get; set; }

    public double Roomtotal { get; set; }

    public double Bedtotal { get; set; }

    public string Meal { get; set; } = null!;

    public double Mealtotal { get; set; }

    public double Finaltotal { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace BlueBird.Models;

public partial class EmpLogin
{
    public int Empid { get; set; }

    public string EmpEmail { get; set; } = null!;

    public string EmpPassword { get; set; } = null!;
}
